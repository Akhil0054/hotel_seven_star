
AOS.init();


// JavaScript for dynamic navbar behavior
window.addEventListener("scroll", function () {
    const navbar = document.querySelector(".navbar");
    if (window.scrollY > 100) { 
      navbar.classList.remove("transparent");
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
      navbar.classList.add("transparent");
    }
  });
// JavaScript for dynamic navbar behavior
  




// start top scroll button 
const scrollToTopButton = document.getElementById('scrollToTop');

window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        scrollToTopButton.classList.add('visible');
    } else {
        scrollToTopButton.classList.remove('visible');
    }
});

scrollToTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth',
    });
});
// end top scroll button 






// start service section 
  
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 1, 
  spaceBetween: 30,
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  autoplay: {
      delay: 3000, 
      disableOnInteraction: false,
  },
  breakpoints: {
      640: {
          slidesPerView: 1, 
          spaceBetween: 10,
      },
      768: {
          slidesPerView: 2, 
          spaceBetween: 20,
      },
      1024: {
          slidesPerView: 3, 
          spaceBetween: 30,
      },
  },
});
// end service section 